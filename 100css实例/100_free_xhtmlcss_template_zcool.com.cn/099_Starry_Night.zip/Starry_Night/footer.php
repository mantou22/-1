<div class="footer">
			<div class="footer_txt">
				<b>Design</b> by <a href="http://www.templatekingdom.com/">Template Kingdom</a> | <b>Sponsored</b> by <a href="http://www.design2please.com/">Design2Please</a> | <a href="http://www.submit2please.com/">Submit2Please</a></div>
		</div>
